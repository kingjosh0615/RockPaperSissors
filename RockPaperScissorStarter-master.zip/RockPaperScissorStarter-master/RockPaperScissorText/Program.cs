﻿using System;

namespace RockPaperScissorText
{
    class Program
    {
        static void Main(string[] args)
        {
            runRPS();
        }

        static void runRPS()
        {
            RPSLogic.AgeValidation();
        }
    }
}
